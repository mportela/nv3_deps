Development Lead
----------------

- Ian Cordasco <graffatcolmingov@gmail.com>

Requests
````````

- Kenneth Reitz <me@kennethreitz.com>

Design Advice
-------------

- Cory Benfield
