pymssql - simple MS SQL Python extension module
===============================================

A simple database interface to Microsoft SQL Server (MS-SQL) for `Python`_ that
builds on top of `FreeTDS`_ to provide a Python DB-API (`PEP-249`_) interface to
SQL Server.

.. _Python: http://www.python.org/
.. _PEP-249: http://www.python.org/dev/peps/pep-0249/
.. _FreeTDS: http://www.freetds.org/

Detailed information on pymssql is available on the website:

https://code.google.com/p/pymssql/

New development is happening on GitHub at:

https://github.com/pymssql/pymssql

There is a Google Group for discussion at:

https://groups.google.com/forum/?fromgroups#!forum/pymssql


Do you use pymssql?
-------------------

Can you take a minute and fill out this survey to help us prioritize development tasks?

https://www.surveymonkey.com/s/KMQ8BM5


Fri Oct 11 10:26:00 2013  Marc Abramowitz

+ bugfix: Fix bug in get_result looping over dbresults where no result
  rows are returned from queries with newer versions of FreeTDS
  https://github.com/pymssql/pymssql/issues/137
  Fixed by git commit: 5033df54c1f67ad92718b4852659b07708765c9b
* version 1.0.3

See ChangeLog for more...
